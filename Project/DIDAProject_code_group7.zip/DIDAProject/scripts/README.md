This folder contains the test to be run during the checkpoint week of the DAD course.

If you need to simplify/modify the test, take note of all the changes.

If you want to additionally run more sophisticated test, you will have the chance to do it.

The files in this archive are:

* pmscript2 : the PuppetMaster script to be tested.
* app2 : the application script containing the operators and their order
* app2_data : data for app2 to populate (pre-load) the storage
* LibOperator.dll : library including the operators of app2
* Operator.cs : source code of the operators of app2
